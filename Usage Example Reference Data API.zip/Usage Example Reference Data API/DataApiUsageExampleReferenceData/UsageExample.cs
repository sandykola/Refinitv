﻿using System;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.ReferenceData;

namespace DataApiUsageExampleReferenceData
{
    public class SymbologyExample
    {
        private readonly IDataServices services;

        public SymbologyExample(IDataServices services)
        {
            this.services = services;
        }

        public void Launch()
        {
            Console.WriteLine("[1] Symbology conversion example");
            Console.WriteLine("");
            
            SymbolsRequest();
        }

        private void SymbolsRequest()
        {
            Console.WriteLine("Converting US0378331005 to a RIC");

            services.ReferenceData.RequestSymbols(new[] { "US0378331005"}, SymbolType.Isin,
                SymbolsOnResponse);
        }

        private void SymbolsOnResponse(SymbolsResponse response)
        {
            if (response.HasError)
            {
                Console.WriteLine(response.Error.Message);
            }
            else
            {
                foreach (var entity in response.Symbols)
                {
                    Console.WriteLine(entity.HasError ? entity.ErrorMessage : entity.BestMatch.Ric);
                }
            }

            Program.StopMessagePump();
        }
    }
}
