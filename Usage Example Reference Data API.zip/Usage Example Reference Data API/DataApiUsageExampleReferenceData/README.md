### Thomson Reuters .NET Data API Usage Example

#### Reference data API

The project consist of a set of classes each demonstrating an individual part of Data API's functionality in **UsageExample.cs** 
and a list of functions calling the usage examples in **Program.cs** inside the **UsageExamples** region.

The following functionality is demonstrated:

+ Symbol conversion request

***WARNING***: This usage example application does not contain the required nuget packages.

Right-click on the solution, select ***Enable NuGet Package Restore*** and select Yes. After that select 
Build, Build Solution in the Visual Studio menu bar or, alternatively, press <kbd>F6</kbd>.

Nuget will restore the missing packages.

For more information please visit Thomson Reuters Developer Community: https://developers.thomsonreuters.com

