﻿using System;
using System.Windows.Threading;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.TimeSeries;

/*
 * WARNING: This usage example application does not contain the required nuget packages. Right-click on the solution, select
 * "Enable NuGet Package Restore" and select Yes. After that select Build, Build Solution in the Visual Studio menu bar.
 * 
 * Nuget will do restore the missing packages.
 * 
 */

namespace DataApiUsageExampleTimeseriesData
{
    class Program
    {
        private static readonly DispatcherFrame Frame = new DispatcherFrame(); //the object is required in order to release the Windows message pump while executing asynchronous calls.

        static void Main(string[] args)
        {
            InitializeDataServices("DataApiUsageExampleTimeseriesData");
            Dispatcher.PushFrame(Frame);
        }

        public static void StopMessagePump()
        {
            Frame.Continue = false;
            Console.WriteLine();
            Console.WriteLine("For other usage examples please uncomment the required method call in timeSeries_ServiceInformationChanged().");
            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        #region IDataServices

        public static IDataServices Services { get; private set; }

        /// <summary>The initialization method for the DataServices instance.</summary>
        /// <param name="appName">A <see cref="System.String"/> with your app name.</param>
        private static void InitializeDataServices(string appName)
        {
            Services = DataServices.Instance;
            Services.StateChanged += ServicesOnStateChanged;

            Services.Initialize(appName);
            InitializeTimeseries();
        }

        /// <summary>The <see cref="IDataServices.StateChanged"/> event handler.</summary>
        /// <param name="sender"></param>
        /// <param name="dataServicesStateChangedEventArgs">StateChanged event arguments.</param>
        private static void ServicesOnStateChanged(object sender, DataServicesStateChangedEventArgs dataServicesStateChangedEventArgs)
        {

        }

        #endregion

        #region UsageExample

        private static ITimeSeriesDataService timeSeries;

        private static void InitializeTimeseries()
        {
            timeSeries = DataServices.Instance.TimeSeries;
            timeSeries.ServiceInformationChanged += timeSeries_ServiceInformationChanged;
        }

        private static void timeSeries_ServiceInformationChanged(object sender, ServiceInformationChangedEventArgs e)
        {
            Console.WriteLine("{0}: {1}", e.Information.State, e.Information.Message);

            // Please uncomment the required method call to see the example in action:

            //ViewsAndIntervals();
            TimeSeriesRequest();
            //TimeSeriesSubscription();
            //Filters();
            //Metadata();
            //StatusEventsAndErrors();
        }


        private static void ViewsAndIntervals()
        {
            (new ViewsAndIntervalsExample(timeSeries)).Launch();
        }

        private static void TimeSeriesRequest()
        {
            (new TimeSeriesRequestExample(timeSeries)).Launch();
        }

        private static void TimeSeriesSubscription()
        {
            (new TimeSeriesSubscriptionExample(timeSeries)).Launch();
        }

        private static void Filters()
        {
            (new FiltersExample(timeSeries)).Launch();
        }

        private static void Metadata()
        {
            (new MetadataExample(timeSeries)).Launch();
        }

        private static void StatusEventsAndErrors()
        {
            (new StatusEventsAndErrorsExample(timeSeries)).Launch();
        }

        #endregion
    }
}
