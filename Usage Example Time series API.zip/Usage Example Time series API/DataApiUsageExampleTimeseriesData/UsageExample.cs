﻿using System;
using System.Collections.Generic;
using System.Linq;

using ThomsonReuters.Desktop.SDK.DataAccess.TimeSeries;
using ThomsonReuters.Desktop.SDK.DataAccess.TimeSeries.Metadata;

namespace DataApiUsageExampleTimeseriesData
{
    #region Views and intervals

    public class ViewsAndIntervalsExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private IViewListRequest viewListRequest;

        public ViewsAndIntervalsExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[1] Views and intervals example");
            Console.WriteLine("");
            
            viewListRequest = timeSeries.GetViewList("AAPL.O", ViewsCallback);
        }

        private void ViewsCallback(IEnumerable<View> views)
        {
            foreach (var view in views)
            {
                var interval = view.Intervals.First();
                var field = interval.Fields.First();

                Console.WriteLine("{0}/{1}:{2}/{3}",
                    view.Name,
                    interval.Length,
                    interval.Type,
                    field.Description);
            }
            viewListRequest = null;

            Program.StopMessagePump();
        }

    }


    #endregion

    #region Time series request

    public class TimeSeriesRequestExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private ITimeSeriesDataRequest request;

        public TimeSeriesRequestExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[2] Time series request example");
            Console.WriteLine("");
            
            request = timeSeries.SetupDataRequest("EUR=")
                .WithView("BID")
                .WithAllFields()
                .WithInterval(CommonInterval.Daily)
                .WithNumberOfPoints(10)
                .OnDataReceived(DataReceivedCallback)
                .CreateAndSend();
        }

        private void DataReceivedCallback(DataChunk chunk)
        {
            foreach (IBarData bar in chunk.Records.ToBarRecords())
            {
                if (bar.Open.HasValue && bar.High.HasValue && bar.Low.HasValue && bar.Close.HasValue && bar.Timestamp.HasValue)
                {
                    Console.WriteLine(
                        "{0}: EUR= OHLC {1} {2} {3} {4}",
                        bar.Timestamp.Value.ToShortDateString(),
                        bar.Open.Value.ToString("##.0000"),
                        bar.High.Value.ToString("##.0000"),
                        bar.Low.Value.ToString("##.0000"),
                        bar.Close.Value.ToString("##.0000")
                    );
                };
            }

            if (!chunk.IsLast) return;

            request = null;
            Program.StopMessagePump();
        }
    }

    #endregion

    #region Time series subscription

    public class TimeSeriesSubscriptionExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private ITimeSeriesDataSubscription subscription;
        private int counter = 0;
        public TimeSeriesSubscriptionExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[3] Time series subscription example");
            Console.WriteLine("");
            
            subscription = timeSeries.SetupDataSubscription("EUR=")
                .WithView("BID")
                .WithAllFields()
                .WithInterval(CommonInterval.Intraday1Minute)
                .From(DateTime.Now.AddHours(-3))
                .OnDataReceived(DataReceivedCallback)
                .OnDataUpdated(DataUpdatedCallback)
                .CreateAndStart();
        }

        private void DataReceivedCallback(DataChunk chunk)
        {
            foreach (IBarData bar in chunk.Records.ToBarRecords())
            {
                if (bar.Open.HasValue && bar.High.HasValue && bar.Low.HasValue && bar.Close.HasValue && bar.Timestamp.HasValue)
                {
                    Console.WriteLine(
                        "{0}: EUR= OHLC {1} {2} {3} {4}",
                        bar.Timestamp.Value.ToLongTimeString(),
                        bar.Open.Value.ToString("##.0000"),
                        bar.High.Value.ToString("##.0000"),
                        bar.Low.Value.ToString("##.0000"),
                        bar.Close.Value.ToString("##.0000")
                    );
                };
            }
        }

        private void DataUpdatedCallback(IDataUpdate dataUpdate)
        {
            IBarData bar = dataUpdate.Records.ToBarRecords().FirstOrDefault();

            if (dataUpdate.UpdateType == UpdateType.NewPoint)
            {
                Console.WriteLine("New point at {0}", bar.Timestamp.Value);
            }
            else if (dataUpdate.UpdateType == UpdateType.ExistingPoint)
            {
                Console.WriteLine("Updated point at {0}", bar.Timestamp.Value);
            }

            if (counter > 5)
            {
                subscription.Stop();
                Program.StopMessagePump();
            }
            else
            {
                counter++;
            }
        }


    }
    #endregion

    #region Filters

    public class FiltersExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private ITimeSeriesDataSubscription subscription;

        public FiltersExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[4] Filters example");
            Console.WriteLine(""); 
            
            Console.WriteLine("Subscribing to all EUR= (BID) time series that are contributed by RBS and are greater than 1.1");
            Console.WriteLine();

            subscription = timeSeries.SetupDataSubscription("EUR=")
                .WithView("BID")
                .WithAllFields()
                .WithInterval(CommonInterval.Quotes)
                .WithNumberOfPoints(50)

                .WithFilter(filter => filter.ContributorIn(new[] { "RBSN" }))
                .WithFilter(filter => filter.NumericValueOfField("BID").GreaterOrEqual(1.1))

                .OnDataReceived(DataReceivedCallback)
                .CreateAndStart();
        }

        private void DataReceivedCallback(DataChunk dataChunk)
        {
            var quotes = dataChunk.Records.ToQuoteRecords();

            foreach (IQuoteData quote in quotes)
            {
                if (quote.Bid.HasValue && quote.Ask.HasValue)
                {
                    Console.WriteLine("{0}: {1}-{2}",
                    quote.Timestamp,
                    quote.Bid,
                    quote.Ask);
                }
            }

            if (dataChunk.IsLast)
            {
                subscription.Stop();
                Program.StopMessagePump();    
            }
        }
    }

    #endregion

    #region Metadata

    public class MetadataExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private IMetadataRequest metadata;

        public MetadataExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[5] Metadata example");
            Console.WriteLine(""); 

            metadata = timeSeries.Metadata.GetCurrencies(CurrenciesCallback);
        }

        private void CurrenciesCallback(IEnumerable<Currency> currencies)
        {
            foreach (var currency in currencies.Take(10))
            {
                Console.WriteLine("{0} ({1}) {2}",
                    currency.ShortName,
                    currency.LongName,
                    currency.Ric);
            }

            metadata = null;

            Program.StopMessagePump();
        }
    }
    #endregion

    #region Status events and errors

    public class StatusEventsAndErrorsExample
    {
        private readonly ITimeSeriesDataService timeSeries;
        private ITimeSeriesDataRequest request;

        public StatusEventsAndErrorsExample(ITimeSeriesDataService timeSeries)
        {
            this.timeSeries = timeSeries;
        }

        public void Launch()
        {
            Console.WriteLine("[6] Status events and errors example");
            Console.WriteLine(""); 
            
            request = timeSeries.SetupDataRequest("EUR=")
                .WithView("XXXX")
                .WithAllFields()
                .WithInterval(CommonInterval.Daily)
                .WithNumberOfPoints(30)
                .OnDataReceived(DataReceivedCallback)
                .OnStatusUpdated(StatusUpdatedCallback)
                .CreateAndSend();
        }

        private void StatusUpdatedCallback(IRequestStatus status)
        {
            Console.WriteLine("{0}: {1}/{2}", status.Ric, status.State, status.Error);
            
            switch (status.State)
            {
                case RequestState.None:
                    break;
                case RequestState.Live:
                    break;
                case RequestState.Stale:
                    break;
                case RequestState.Blending:
                    break;
                case RequestState.Reload:
                    break;
                case RequestState.Closed:
                    break;
                case RequestState.PartialData:
                    break;
                case RequestState.LoadPartial:
                    break;
                case RequestState.LoadFailed:
                    break;
                case RequestState.NotPermissioned:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            Program.StopMessagePump();
        }

        private void DataReceivedCallback(DataChunk chunk)
        {
            if (chunk.IsLast) Program.StopMessagePump();
        }
    }




    #endregion
}
