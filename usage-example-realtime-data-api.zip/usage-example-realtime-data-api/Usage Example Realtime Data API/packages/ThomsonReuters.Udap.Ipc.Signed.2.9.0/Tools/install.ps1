param($installPath, $toolsPath, $package, $project)
    # This is the native dependency file to copy to the output folder
    $targetsFile = @([System.IO.Path]::Combine($toolsPath, 'EikonPipeDll.dll'), [System.IO.Path]::Combine($toolsPath, 'i18nresource.dll'), [System.IO.Path]::Combine($toolsPath, 'msvcp120.dll'), [System.IO.Path]::Combine($toolsPath, 'msvcr120.dll'))
 
    # Need to load MSBuild assembly if it's not loaded yet.
    Add-Type -AssemblyName 'Microsoft.Build, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'

    # Grab the loaded MSBuild project for the project
    $msbuild = [Microsoft.Build.Evaluation.ProjectCollection]::GlobalProjectCollection.GetLoadedProjects($project.FullName) | Select-Object -First 1
 
    # Make the path to the native file relative.
    $projectUri = new-object Uri($project.FullName, [System.UriKind]::Absolute)
   
    # Add a target to check and to copy native dependencies
    $target = $msbuild.Xml.AddTarget("EikonSdkIpc_CopyNativeDependencies")
    $target.AfterTargets = "AfterBuild"
	
	foreach ($targetFile in $targetsFile) {
		# copy file to output
		$targetUri = new-object Uri($targetFile, [System.UriKind]::Absolute)
		$relativePath = [System.Uri]::UnescapeDataString($projectUri.MakeRelativeUri($targetUri).ToString()).Replace([System.IO.Path]::AltDirectorySeparatorChar, [System.IO.Path]::DirectorySeparatorChar)
		
		# if the file don't exist at the time the target runs, package restore didn't run
		$errorTask = $target.AddTask("Error")
		$errorTask.Condition = "!Exists('$relativePath')"
		$errorTask.SetParameter("Text", "This project needs a file provided by a NuGet package that is missing on this computer. Enable NuGet Package Restore to download it.  For more information, see http://go.microsoft.com/fwlink/?LinkID=317567.");
		$errorTask.SetParameter("HelpKeyword", "EIKONSDKBUILD0001");
		
		$copyTask = $target.AddTask("Copy")
		$copyTask.Condition = "Exists('$relativePath')"
		$copyTask.SetParameter("SourceFiles", "$relativePath");
		$copyTask.SetParameter("DestinationFolder", "`$(OutputPath)");
		$copyTask.ContinueOnError = "True";
	}
	
    $project.Save()