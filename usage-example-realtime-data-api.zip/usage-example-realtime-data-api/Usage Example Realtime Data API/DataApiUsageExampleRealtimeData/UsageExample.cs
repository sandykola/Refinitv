﻿using System;
using System.Collections.ObjectModel;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Realtime;

namespace DataApiUsageExampleRealtimeData
{

    #region Single value request and subscription

    public class SingleValueRequestAndSubscriptionExample
    {
        private IRealtimeSingleDataRequest singleRequest;
        private IRealtimeSingleDataSubscription singleSubscription;

        private int counter;

        public void Launch()
        {
            Console.WriteLine("[1] Single value request and subscription example");
            Console.WriteLine("");

            var realtime = DataServices.Instance.Realtime;
            counter = 0;

            singleRequest = realtime.Request("GBP=", "BID", DataReceived);
            singleSubscription = realtime.Subscribe("EUR=", "BID", DataReceived);
        }

        private void DataReceived(SingleFieldValue value)
        {
            Console.WriteLine("{0}:{1}({2}) {3}",
                    counter,
                    value.Ric,
                    value.Field,
                    value.RawValue);

            counter += 1;

            if (counter == 5)
            {
                singleRequest = null;
                singleSubscription.Stop();
                singleSubscription = null;
                Console.WriteLine("Stopped");

                Program.StopMessagePump();
            }
        }

    }

    #endregion

    #region Complex request and subscription

    public class ComplexRequestAndSubscriptionExample
    {
        private IRealtimeDataRequest request;
        private IRealtimeDataSubscription subscription;

        public void Launch()
        {
            Console.WriteLine("[2] Complex request and subscription example");
            Console.WriteLine("");
            
            var realtime = DataServices.Instance.Realtime;

            request =
                realtime.SetupDataRequest()
                    .WithRics("BRL=", "RUB=")
                    .WithFields("BID", "ASK")
                    .OnDataReceived(DataReceivedCallback)
                    .CreateAndSend();

            subscription =
                realtime.SetupDataSubscription()
                    .WithRics("EUR=", "GBP=")
                    .WithFields("BID", "ASK")
                    .OnDataUpdated(DataReceivedCallback)
                    .CreateAndStart();
        }

        private void DataReceivedCallback(IRealtimeUpdateDictionary updates)
        {
            if (updates.ContainsKey("EUR="))
            {
                if (updates["EUR="].ContainsKey("BID"))
                {
                    Console.WriteLine("EUR=(BID) {0}", updates["EUR="]["BID"].Value.ToString());
                    subscription.Stop();

                    Program.StopMessagePump();
                }
            }
        }
    }

    #endregion

    #region Instrument-level status events

    public class InstrumentLevelStatusEventsExample
    {
        private IRealtimeDataSubscription subscription;

        public void Launch()
        {
            Console.WriteLine("[3] Instrument level status events example");
            Console.WriteLine("");
            
            var realtime = DataServices.Instance.Realtime;

            subscription = realtime.SetupDataSubscription()
                        .WithRics("EUR=")
                        .WithFields("BID", "ASK")
                        .OnDataUpdated(DataReceivedCallback)
                        .OnStatusUpdated(StatusUpdatesCallback) //status events
                        .CreateAndStart();
        }

        private void StatusUpdatesCallback(InstrumentStateUpdate status)
        {
       
            Console.WriteLine ("{0} {1}", status.Ric, status.InstrumentState.ToString());

            switch (status.InstrumentState)
            {
                case InstrumentState.None:
                    break;
                case InstrumentState.Pending:
                    break;
                case InstrumentState.Ok:
                    Program.StopMessagePump();
                    break;
                case InstrumentState.Stale:
                    break;
                case InstrumentState.Closed:
                    break;
                case InstrumentState.Info:
                    break;
                case InstrumentState.Delayed:
                    break;
                case InstrumentState.NoPermission:
                    break;
                case InstrumentState.OpenedSubscriptionsLimitExceeded:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            
        }

        private void DataReceivedCallback(IRealtimeUpdateDictionary obj)
        {

        }
    }

    #endregion

    #region Chain request

    public class ChainRequestExample
    {
        private IChainRequest chainRequest;

        public void Launch()
        {
            Console.WriteLine("[4] Chain request example");
            Console.WriteLine("");
            
            var realtime = DataServices.Instance.Realtime;

            chainRequest = realtime.GetChain("0#RUBZ=R", true, ConstituentsCallback, ChainErrorCallback);
        }

        private void ConstituentsCallback(ReadOnlyCollection<string> constituents)
        {
            Console.WriteLine(string.Join("\r\n", constituents));
            Program.StopMessagePump();
        }

        private void ChainErrorCallback(ChainError chainError)
        {
            switch (chainError.Type)
            {
                case ChainErrorType.None:
                    break;
                case ChainErrorType.Empty:
                    break;
                case ChainErrorType.NotAChain:
                    break;
                case ChainErrorType.NoPermission:
                    break;
                case ChainErrorType.OpenedSubscriptionLimitExceeded:
                    break;
                case ChainErrorType.StartFailed:
                    break;
                case ChainErrorType.StopFailed:
                    break;
                case ChainErrorType.Other:
                    break;
                case ChainErrorType.Stale:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }

    #endregion

    #region Chain subscription

    public class ChainSubscriptionExample
    {
        private IChainSubscription chainSubscription;
        private int counter = 0;

        public void Launch()
        {
            Console.WriteLine("[4] Chain subscription example");
            Console.WriteLine("");
            
            var realtime = DataServices.Instance.Realtime;

            chainSubscription = realtime.SetupChainSubscription("EURBEST=")
                .OnDataUpdated(ChainUpdatedCallback)
                .OnError(ChainErrorCallback)
                .CreateAndStart();
        }

        private void ChainUpdatedCallback(ChainChunk chainChunk)
        {
            foreach (var update in chainChunk.Updates)
            {
                switch (update.UpdateType)
                {
                    case UpdateType.Added:
                        Console.WriteLine("{0} added at position {1}", update.Ric, update.Position);
                        break;
                    case UpdateType.Removed:
                        Console.WriteLine("{0} removed", update.Ric);
                        break;
                    case UpdateType.Changed:
                        Console.WriteLine("{0} position changed to {1}", update.Ric, update.Position);
                        break;
                }
            }

            if (chainChunk.IsLast)
            {
                Console.WriteLine("End of update");
            }


            if (counter > 20)
            {
                chainSubscription.Stop();

                Console.WriteLine("Subscription stopped");
                Program.StopMessagePump();
            }
            else
            {
                counter++;
            }
        }
        private void ChainErrorCallback(ChainError chainError)
        {

        }
    }
    #endregion

}
