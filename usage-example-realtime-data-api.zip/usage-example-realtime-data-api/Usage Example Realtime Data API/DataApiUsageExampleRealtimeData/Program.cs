﻿using System;
using System.Windows.Threading;
using ThomsonReuters.Desktop.SDK.DataAccess;
using ThomsonReuters.Desktop.SDK.DataAccess.Common;

/*
 * WARNING: This usage example application does not contain the required nuget packages. Right-click on the solution, select
 * "Enable NuGet Package Restore" and select Yes. After that select Build, Build Solution in the Visual Studio menu bar.
 * 
 * Nuget will do restore the missing packages.
 * 
 */

namespace DataApiUsageExampleRealtimeData
{
    class Program
    {

        private static readonly DispatcherFrame Frame = new DispatcherFrame(); //the object is required in order to release the Windows message pump while executing asynchronous calls.
        
        static void Main(string[] args)
        {
            InitializeDataServices("DataApiUsageExampleRealtimeData");

            // Please uncomment the required method call to see the example in action:

            SingleValueRequestAndSubscription(); 
            //ComplexRequestAndSubscription(); 
            //InstrumentLevelStatusEvents(); 
            //ChainRequest();
            //ChainSubscription();

            Dispatcher.PushFrame(Frame);
        }

        public static void StopMessagePump()
        {
            Frame.Continue = false;
            Console.WriteLine();
            Console.WriteLine("For other usage examples please uncomment the required method call in Main().");
            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        #region IDataServices

        private static IDataServices Services { get; set; }

        /// <summary>The initialization method for the DataServices instance.</summary>
        /// <param name="appName">A <see cref="System.String"/> with your app name.</param>
        private static void InitializeDataServices(string appName)
        {
            Services = DataServices.Instance;
            Services.StateChanged += ServicesOnStateChanged;

            Services.Initialize(appName);
        }

        /// <summary>The <see cref="IDataServices.StateChanged"/> event handler.</summary>
        /// <param name="sender"></param>
        /// <param name="dataServicesStateChangedEventArgs">StateChanged event arguments.</param>
        private static void ServicesOnStateChanged(object sender, DataServicesStateChangedEventArgs dataServicesStateChangedEventArgs)
        {
            switch (dataServicesStateChangedEventArgs.State)
            {
                case DataServicesState.None:
                    break;
                case DataServicesState.Error:
                    break;
                case DataServicesState.Up:
                    break;
                case DataServicesState.Down:
                    break;
                case DataServicesState.LocalMode:
                    break;
                case DataServicesState.EikonClosing:
                    break;
                case DataServicesState.EikonStarting:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        #endregion

        #region UsageExamples

        private static void SingleValueRequestAndSubscription()
        {
            (new SingleValueRequestAndSubscriptionExample()).Launch();
        }

        private static void ComplexRequestAndSubscription()
        {
            (new ComplexRequestAndSubscriptionExample()).Launch();
        }

        private static void InstrumentLevelStatusEvents()
        {
            (new InstrumentLevelStatusEventsExample()).Launch();
        }

        private static void ChainRequest()
        {
            (new ChainRequestExample()).Launch();
        }

        private static void ChainSubscription()
        {
            (new ChainSubscriptionExample()).Launch();
        }

        #endregion

    }
}
